#include <iostream>
#include <math.h>
int totalNumber(int g,int f,int y){
  double totalSum = (g*f)+y;     //functions
  std::cout<<"Show the value of the Total sum:"<<totalSum;
  return totalSum;
}
int main(int argc, char **argv) {
    int first {3};  //Declared values
    int second {4};
    std::cout<<"First number:"<<first;
    std::cout<<"\nSecond number:"<<second;
    int sum = first * second;  //first value of functions
    std::cout<<"\nValue of the sum:"<<sum;
    sum = 24+9;    //Second value of functions
    std::cout<<"\nTotal value of the new sum:"<<sum;
    sum = 90+7;    //Third value of functions
    std::cout<<"\nSecond new value of the new sum::"<<sum;
    sum = 0*1;    //Last value of functions
    std::cout<<"\nFinal value of the sum is::"<<sum;
    std::cout<<"\nValue of the this statement is:"<<6+9;
    
  return 0;
}